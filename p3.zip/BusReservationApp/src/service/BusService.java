package service;

public interface BusService {

}
