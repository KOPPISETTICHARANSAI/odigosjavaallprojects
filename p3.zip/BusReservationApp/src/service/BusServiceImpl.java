package service;

public class BusServiceImpl {
	public BusServiceImpl(){
		
	}
}
