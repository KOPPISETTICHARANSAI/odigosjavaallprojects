package model;

public class Bus {

}
