package dao;

public interface BusDao {

}
