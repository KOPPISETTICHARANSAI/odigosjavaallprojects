package dao;

public class BusDaoImpl {

}
